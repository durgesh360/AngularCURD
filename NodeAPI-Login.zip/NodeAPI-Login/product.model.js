const mongoose = require('mongoose');

const ProductSchema = mongoose.Schema({
    firstName: String,
    lastName: String,
    username: String,
    password: String,
    company: String
}, {
    timestamps: true
});

module.exports = mongoose.model('login', ProductSchema);
module.exports = (app) => {
    const products = require('./product.controller.js');

    // Create a new Product
    app.post('/users', products.create);

    

    // Retrieve all Products
    app.get('/users', products.findAll);

    // Retrieve a single Product with productId
    app.post('/auth', products.findOneAuth);

    app.get("/users/:id", products.findOne);

    // Update a Note with productId
    app.put('/users/:id', products.update);

    // Delete a Note with productId
    app.delete('/users/:id', products.delete);
}
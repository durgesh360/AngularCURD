import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

//const baseUrl = 'http://localhost:3000/products';

const baseUrl = 'http://localhost:8080/api/tutorials';

const loginUrl = 'http://localhost:8081/users';
@Injectable({
  providedIn: 'root'
})
export class TutorialService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get(baseUrl);
  }

  getUserList() {
    return this.http.get(loginUrl);
  }

  getUserById(id) {
    return this.http.get(`${loginUrl}/${id}`);
  }

  get(id) {
    
    return this.http.get(`${baseUrl}/${id}`);
  }

  login(data) {
    debugger;
    return this.http.post(loginUrl, data);
  }

  create(data) {
    return this.http.post(baseUrl, data);
  }

  update(id, data) {
    debugger;
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  loginData(id, data) {
    debugger;
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  delete(id) {
    debugger;
    return this.http.delete(`${baseUrl}/${id}`);
  }
  deleteAll() {
    return this.http.delete(baseUrl);
  }

  findByTitle(title) {
    return this.http.get(`${baseUrl}?title=${title}`);
  }
}

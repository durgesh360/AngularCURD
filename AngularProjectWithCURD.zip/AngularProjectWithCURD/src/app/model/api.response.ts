export class ApiResponse {

  status: number;
  message: number;
  recordsets: any;
  recordset: any;
  response: number;
}

import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user.service';
import {Router} from "@angular/router"; 
import {Users} from "../../model/user.model";
import { TutorialService } from 'src/app/services/tutorial.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  userList: any;
  
  userListData: any;
  currentTutorial = null;
  currentIndex = -1;
  title = '';

  constructor(private router: Router,private userService: UserService,private tutorialService: TutorialService) { }

  ngOnInit() {
    if(!window.localStorage.getItem('userData')) {
      this.router.navigate(['login']);
      return;
    }
    //const userList=
    debugger;
    //const userList =
    this.retrieveUserList();
    //console.log("datam" + userList);
    	//	this.success(userList);

  }

  

  retrieveUserList() {
    debugger;
    this.tutorialService.getUserList()
      .subscribe(
        data => {
          this.userList = data;
          console.log("new data" + data);
        },
        error => {
          console.log(error);
        });
  }

  // Get student list success
	success(data) {
    debugger;
		this.userListData = data.data;
		for (let i = 0; i < this.userListData.length; i++) {
			this.userListData[i].name = this.userListData[i].firstName + ' ' + this.userListData[i].lastName;
		}
	}


}

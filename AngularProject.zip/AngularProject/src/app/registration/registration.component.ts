import { Component, OnInit } from '@angular/core';

import {FormBuilder, FormGroup, Validators} from "@angular/forms";

import { TutorialService } from 'src/app/services/tutorial.service';
import { first } from 'rxjs/operators';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  index: any;
  userList: any;
  
  constructor(private tutorialService: TutorialService, private route: ActivatedRoute, private formBuilder: FormBuilder,
    private router: Router
) { 
  // this.route.queryParams.subscribe(params=>{

  //   console.log('Got the param as: ', params['_id']);
  
  // })
     


}

  ngOnInit() {

    debugger;
    // this.route.queryParams.subscribe(params => {
    //   this.index = params['_id'];
    //   // check if ID exists in route & call update or add methods accordingly
    //   debugger;
    //   if (this.index && this.index !== null && this.index !== undefined) {
    //     this.getUserDetails(this.index);
    //   } else {
        
    //   }
    // });
    this.createForm(null);
  }

// If this is update request then auto fill form
createForm(data) {
  debugger;
  if (data === null) {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
  });

  }
  else{

    this.registerForm = this.formBuilder.group({
      firstName: [data.registerForm.firstName, Validators.required],
      lastName: [data.registerForm.lastName, Validators.required],
      username: [data.registerForm.username, Validators.required],
      password: [data.registerForm.password, [Validators.required, Validators.minLength(6)]]
  });
  }
}

// If this is update form, get user details and update form
getUserDetails(index: String) {
  debugger;
 //const studentDetail = 
 this.retrieveUserList(index);
console.log(this.userList);
  this.createForm(this.userList);
}

retrieveUserList(index: String) {
  debugger;
  this.tutorialService.getUserById(index)
  .subscribe( data => {
    //this.editForm.setValue(data[0]);
    console.log(data[0]);
    console.log(data);
  });

      //return this.userList;
}



  get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        //this.alertService.clear();

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
debugger;
        this.loading = true;
        this.tutorialService.login(this.registerForm.value)
            .pipe(first())
            .subscribe(
                data => {
                  console.log(data);
                //alert("done");
                   // this.alertService.success('Registration successful', true);
                    this.router.navigate(['/login']);
                },
                error => {
                    //this.alertService.error(error);
                    this.loading = false;
                });
    }

}

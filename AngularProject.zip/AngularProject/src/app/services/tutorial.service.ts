import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

//const baseUrl = 'http://localhost:3000/products';

const baseUrl = 'http://localhost:8080/api/tutorials';

const loginUrl = 'http://localhost:8081/users';
const loginAuth = 'http://localhost:8081/auth';
@Injectable({
  providedIn: 'root'
})
export class TutorialService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get(baseUrl);
  }

  getUserList() {
    return this.http.get(loginUrl);
  }

  getUserById(id) {
    debugger;
    return this.http.get(`${loginUrl}/${id}`);
  }

  get(id) {
    
    return this.http.get(`${baseUrl}/${id}`);
  }

  login(data) {
    debugger;
    return this.http.post(loginAuth, data);
  }

  create(data) {
    return this.http.post(baseUrl, data);
  }

  update(id, data) {
    debugger;
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  updateUser(id, data) {
    debugger;
    return this.http.put(`${loginUrl}/${id}`, data);
  }

  loginData(id, data) {
    debugger;
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  delete(id) {
    debugger;
    return this.http.delete(`${baseUrl}/${id}`);
  }
  deleteUser(id) {
    debugger;
    return this.http.delete(`${loginUrl}/${id}`);
  }

  

  deleteAll() {
    return this.http.delete(baseUrl);
  }

  findByTitle(title) {
    return this.http.get(`${baseUrl}?title=${title}`);
  }
}

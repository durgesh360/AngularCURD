import { Component, OnInit } from '@angular/core';
import { TutorialService } from 'src/app/services/tutorial.service';
import { FormBuilder } from "@angular/forms";
import {ActivatedRoute,Router} from "@angular/router";
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.component.html',
  styleUrls: ['./add-tutorial.component.css']
})
export class AddTutorialComponent implements OnInit {

  oppoSuits: any = ['Mini', 'ThinkPad', 'Super Mini', 'Inspiration']

  tutorial = {

    price: '',
    company: '',
    title: '',
    description: '',
    published: false
  };
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,private tutorialService: TutorialService, public fb: FormBuilder) { }

 

  ngOnInit() {
    if(!window.localStorage.getItem('userData')) {
      this.router.navigate(['login']);
      return;
    }
  }

  // changeSuit(e) {
  //   this.oppoSuitsForm.get('Brand').setValue(e.target.value, {
  //      onlySelf: true
  //   })
  // }
  saveTutorial(form,tutorial) {
debugger;
    console.log('submitted formdata',tutorial);
    // const data = {
    //   title: this.tutorial.title,
    //   description: this.tutorial.description,
    //   published: this.tutorial.published,
    //   price: this.tutorial.price,
    //   company: this.tutorial.company
    
    // };

    this.tutorialService.create(tutorial)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newTutorial() {
    this.submitted = false;
    this.tutorial = {
      price: '',
      company: '',
      title: '',
      description: '',
      published: false
    };
  }

}

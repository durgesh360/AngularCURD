export class Users {

  _id: number;
  firstName: String;
  lastName: String;
  username: String;
  password: String;
}

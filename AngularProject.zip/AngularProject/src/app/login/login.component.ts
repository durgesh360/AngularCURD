import { Component, OnInit } from '@angular/core';
import { TutorialService } from 'src/app/services/tutorial.service';
import { UserService } from 'src/app/services/user/user.service';
import {ActivatedRoute,Router} from "@angular/router";
import { Validators, FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  userList: any;
  Drug : string[] ;
  Drugs : object [];

  outputData : String;
  constructor(private route: ActivatedRoute,private formBuilder: FormBuilder,private router: Router, private tutorialService: TutorialService,private userService: UserService) { 

    this.loginForm = this.formBuilder.group({
			username: ['', [Validators.required]],
			password: ['', [Validators.required]]
		});
  }


  ngOnInit() {
  }
// Initicate login
doLogin() {
  //this.tutorialService.login(this.loginForm.value);
//debugger;
  this.tutorialService.login(this.loginForm.value)
  .subscribe(
    data => {
      
      //console.log("new datae" + data);

      //this.userList =  JSON.stringify(data);
     // console.log("new data" + JSON.stringify(data));
      console.log("test" +data["Success"]);

      this.outputData=data["Success"];
      console.log("KJ" + this.outputData);
   //  this.Drugs=data["Success"];
    // console.log(this.Drugs);

    if(this.outputData=="Success!")
    {
      localStorage.setItem('userData', this.userList);
     
      this.router.navigate(['/tutorials']);
  
  
    }
    else
    {
      alert(this.outputData);
    }
  
    },
    error => {
      console.log(error);
    });

debugger;
    //alert("d:" + this.userList);

//  const login = this.userService.doLogin(this.loginForm.value);
  //this.success(login);

  
}


// Login success function
success(data) {
  if (data.code === 200) {
    localStorage.setItem('userData', JSON.stringify(data.data));
    
    alert( 'Logged In Successfully');
    this.router.navigate(['/tutorials']);
  } else {
    alert( 'Invalid');
    //this.toastr.error('Failed', 'Invalid Credentials');
  }
}
}

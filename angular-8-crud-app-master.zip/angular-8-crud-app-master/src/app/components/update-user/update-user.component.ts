import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import {Users} from "../../model/user.model";

import { TutorialService } from 'src/app/services/tutorial.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  userId: any;
 
  userList: any = {};
  constructor(private route: ActivatedRoute,private formBuilder: FormBuilder,private router: Router, private tutorialService: TutorialService) { }

  ngOnInit() {
    this.userList = new Users();
    debugger;
    this.route.queryParams.subscribe(params => {
      this.userId = params['_id'];
      // check if ID exists in route & call update or add methods accordingly
      //alert(this.userId);
      debugger;
      if (this.userId && this.userId !== null && this.userId !== undefined) {
        debugger;
        this.tutorialService.getUserById(this.userId)
          .subscribe( data => {
            //this.editForm.setValue(data[0]);
              this.userList=data;
              console.log("new data"+ data);
              console.log("new data1"+ this.userList);
          });
      } 
    });
  }


  onSubmit() {
    this.updateUser();    
     this.gotoList();
    
}

updateUser() {
 //let id = window.localStorage.getItem("editUserId");
 alert(this.userId);
 debugger;
 this.tutorialService.updateUser(this.userId,this.userList)
 .subscribe(
   response => {
     console.log(response);
     //this.submitted = true;
   },
   error => {
     console.log(error);
   });

}

gotoList() {
 this.router.navigate(['/userlist']);
}
}

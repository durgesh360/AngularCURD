import { Component, OnInit } from '@angular/core';
import { TutorialService } from 'src/app/services/tutorial.service';
import { FormBuilder } from "@angular/forms";


@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.component.html',
  styleUrls: ['./add-tutorial.component.css']
})
export class AddTutorialComponent implements OnInit {

  oppoSuits: any = ['Mini', 'ThinkPad', 'Super Mini', 'Inspiration']

  tutorial = {

    price: '',
    company: '',
    title: '',
    description: '',
    published: false
  };
  submitted = false;

  constructor(private tutorialService: TutorialService, public fb: FormBuilder) { }

 

  ngOnInit() {
  }

  // changeSuit(e) {
  //   this.oppoSuitsForm.get('Brand').setValue(e.target.value, {
  //      onlySelf: true
  //   })
  // }
  saveTutorial() {
    const data = {
      title: this.tutorial.title,
      description: this.tutorial.description,
      published: this.tutorial.published,
      price: this.tutorial.price,
      company: this.tutorial.company
    
    };

    this.tutorialService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newTutorial() {
    this.submitted = false;
    this.tutorial = {
      price: '',
      company: '',
      title: '',
      description: '',
      published: false
    };
  }

}

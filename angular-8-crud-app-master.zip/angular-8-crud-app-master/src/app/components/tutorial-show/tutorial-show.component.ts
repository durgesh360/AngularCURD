import { Component, OnInit } from '@angular/core';
import { TutorialService } from 'src/app/services/tutorial.service';
import {Router} from "@angular/router"; 
import {Tutorials} from "../../model/tutorial.model";


@Component({
  selector: 'app-tutorial-show',
  templateUrl: './tutorial-show.component.html',
  styleUrls: ['./tutorial-show.component.css']
})
export class TutorialShowComponent implements OnInit {

  tutorials: any;
  currentTutorial = null;
  currentIndex = -1;
  title = '';
  _id='';
  submitted = false;
  constructor(private router: Router,private tutorialService: TutorialService) { }


  ngOnInit() {
    //debugger;
 if(!window.localStorage.getItem('userData')) {
       this.router.navigate(['login']);
       return;
     }


    this.retrieveTutorials();
  }

  retrieveTutorials() {
    //debugger;
    this.tutorialService.getAll()
      .subscribe(
        data => {
          this.tutorials = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrieveTutorials();
    this.currentTutorial = null;
    this.currentIndex = -1;
  }

  setActiveTutorial(tutorial, index) {
    this.currentTutorial = tutorial;
    this.currentIndex = index;
  }

  removeAllTutorials() {
    this.tutorialService.deleteAll()
      .subscribe(
        response => {
          console.log(response);
          this.retrieveTutorials();
        },
        error => {
          console.log(error);
        });
  }

  addUser(): void {
    this.router.navigate(['add']);
  };
  searchTitle() {
    this.tutorialService.findByTitle(this.title)
      .subscribe(
        data => {
          this.tutorials = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  editUser(tutorial: Tutorials): void {
    debugger;
     window.localStorage.removeItem("editUserId");
     window.localStorage.setItem("editUserId", tutorial.id.toString());
    this.router.navigate(['edit-tutorial']);
  };

  deleteTutorials(tutorial) {
    debugger;
    const r = confirm('Are you sure?');
		if (r === true) {
	
    this.tutorialService.delete(tutorial.id)
      .subscribe(
        data => {
          this.submitted = true;
         this.refreshList();
          //this.tutorials = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
      }
  }

}

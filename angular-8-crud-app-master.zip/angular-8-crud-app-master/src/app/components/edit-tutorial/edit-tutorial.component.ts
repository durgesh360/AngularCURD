
import { Component, OnInit , Inject} from '@angular/core';
import {ActivatedRoute,Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import {Tutorials} from "../../model/tutorial.model";

import { TutorialService } from 'src/app/services/tutorial.service';





@Component({
  selector: 'app-edit-tutorial',
  templateUrl: './edit-tutorial.component.html',
  styleUrls: ['./edit-tutorial.component.css']
})
export class EditTutorialComponent implements OnInit {

  //tutorial: Tutorials;
  editForm: FormGroup;
  tutorial: any = {};
  id: string;  
  constructor(private route: ActivatedRoute,private formBuilder: FormBuilder,private router: Router, private tutorialService: TutorialService) { }

  ngOnInit() {
    //debugger;
    this.tutorial = new Tutorials();
    this.id = window.localStorage.getItem("editUserId");

    let userId = window.localStorage.getItem("editUserId");
    if(!userId) {
      alert("Invalid action.");
      this.router.navigate(['details']);
      return;
    }
    this.editForm = this.formBuilder.group({
      _id: [''],
      title: [''],
      description: [''],
      published: [''],
      price: [''],
      company: ['']
    });
    debugger;
    this.tutorialService.get(userId)
      .subscribe( data => {
        //this.editForm.setValue(data[0]);
          this.tutorial=data;
      });

  }


  onSubmit() {
       this.updateTutorial();    
        this.gotoList();
       
  }

  updateTutorial() {
    let id = window.localStorage.getItem("editUserId");
    //alert(id.toString());
    debugger;
    this.tutorialService.update(id,this.tutorial)
    .subscribe(
      response => {
        console.log(response);
        //this.submitted = true;
      },
      error => {
        console.log(error);
      });

  }

  gotoList() {
    this.router.navigate(['/details']);
  }
}

import { Component, OnInit } from '@angular/core';


import { RouterModule, Routes ,Router} from '@angular/router';
//import { ToastrService } from 'ngx-toastr';
 // Services
 import { routerTransition } from '../../services/config/config.service';

 import { AddTutorialComponent } from '../add-tutorial/add-tutorial.component';
import { TutorialDetailsComponent } from '../tutorial-details/tutorial-details.component';
import { TutorialsListComponent } from '../tutorials-list/tutorials-list.component';
import { TutorialShowComponent } from '../tutorial-show/tutorial-show.component';
import { EditTutorialComponent } from '../edit-tutorial/edit-tutorial.component';
import { UserListComponent } from '../user-list/user-list.component';
import { UserDetailComponent } from '../user-detail/user-detail.component';
import { UpdateUserComponent } from '../update-user/update-user.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [routerTransition()],
 	host: {'[@routerTransition]': ''}
})


export class HomeComponent implements OnInit {

  active:string;
  constructor(private router: Router) {
    // Detect route changes for active sidebar menu
    this.router.events.subscribe((val) => {
      this.routeChanged(val);
    });
  }

  ngOnInit() {
  }

// Detect route changes for active sidebar menu
routeChanged(val){
  this.active = val.url;
}

// Logout User
logOut(){
 // this.toastr.success('Success', "Logged Out Successfully");
  localStorage.removeItem('userData');
  this.router.navigate(['/login']);
}

}



 // Define and export child routes of HomeComponent
 export const homeChildRoutes : Routes = [
  {
    path: '',
    component: TutorialShowComponent
  },
  {
    path: 'add',
    component: AddTutorialComponent
  },
  {
    path: 'edit-tutorial',
    component: EditTutorialComponent
  },
  {
    path: 'details',
    component: TutorialShowComponent
  },
  {
    path: 'tutorials',
    component: TutorialsListComponent
  },
  {
    path: 'userlist',
    component: UserListComponent
  },
  {
    path: 'updateuser',
    component: UpdateUserComponent
  },
  {
    path: 'userdetail/:id',
    component: UserDetailComponent
  }
  ];
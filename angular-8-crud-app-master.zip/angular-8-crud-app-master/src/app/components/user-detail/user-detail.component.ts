import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';
import { routerTransition } from '../../services/config/config.service';
import { UserService } from '../../services/user/user.service';
import {Users} from "../../model/user.model";
import { TutorialService } from 'src/app/services/tutorial.service';



@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css'],
  animations: [routerTransition()],
	host: { '[@routerTransition]': ''}
})
export class UserDetailComponent implements OnInit {
  index: any;
  userList: any;
 
  constructor(private router: Router, private route: ActivatedRoute,private tutorialService: TutorialService) { 

debugger;
    // Get user detail index number sent in params
		this.route.params.subscribe(params => {
      this.index = params['id'];
     // alert(this.index);
			if (this.index && this.index != null && this.index !== undefined) {
			 this.getUserDetails(this.index);
			}
		});
  }

  ngOnInit() {
  }
  getUserDetails(index: number) {
		//const getStudentDetail = this.studentService.getStudentDetails(index);
		//if (getStudentDetail) {
		//	this.studentDetail = getStudentDetail.studentData;
		//	this.toastr.success(getStudentDetail.message, 'Success');
  //	}
  debugger;
  this.tutorialService.getUserById(index)
      .subscribe(
        data => {
          this.userList =  data;
          console.log("new data" + data);
        },
        error => {
          console.log(error);
        });
  }
  

}

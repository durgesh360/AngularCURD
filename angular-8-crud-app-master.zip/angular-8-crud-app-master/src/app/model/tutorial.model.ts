export class Tutorials {

  _id: number;
  // Username:string;  
  // Email:string;  
  // name:string;  
  // phone:string;  
  // shippingaddress:string 
    
  title: String;
  description: String;
  published: Boolean;
  price: Number;
  company: String;


  
 
}

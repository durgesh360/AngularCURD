export class Tutorials {

  id: String;
  // Username:string;  
  // Email:string;  
  // name:string;  
  // phone:string;  
  // shippingaddress:string 
    
  title: String;
  description: String;
  published: Boolean;
  price: Number;
  company: String;


  
 
}

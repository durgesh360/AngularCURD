module.exports = {
 url: 'mongodb+srv://test:test123@cluster0-dhrfq.mongodb.net/test?retryWrites=true&w=majority'
 // url: 'mongodb+srv://test:test123@cluster0-tdord.mongodb.net/test?retryWrites=true&w=majority'

};
